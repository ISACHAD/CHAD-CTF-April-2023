#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

/*
* Must have folder directory set up as:
*   craftingencryptedfiles.c
*   files/
*   main-files/
*       alphabet-lowercase.txt
*       JayPeeGee.jpg
*       mybookreport.png
*       secure-data.pdf

* main-files/ directory has all the original files.
* This testing file will read those hardcoded filenames and write the "encrypted" versions of them.
 */

uint32_t read_file(char *filename, unsigned char **contents_out);
uint32_t write_file(char *filename, unsigned char *contents, uint32_t contents_size);
void obfuscator(unsigned char *contents, uint32_t contents_size);
unsigned char rol(unsigned char num, int n);
unsigned char ror(unsigned char num, int n);
void print_buffer(char *buffer, char *name, uint32_t size);
void create_encrypted_file(char *file_name, char *read_filepath, char *write_filepath);

int main(int argc, char **argv){
    

    create_encrypted_file("JayPeeGee", "main-files/JayPeeGee.jpg", "files/JayPeeGee.jpg.encrypted");
    create_encrypted_file("alphabet-lowercase", "main-files/alphabet-lowercase.txt", "files/alphabet-lowercase.txt.encrypted");
    create_encrypted_file("mybookreport", "main-files/mybookreport.png", "files/mybookreport.png.encrypted");
    create_encrypted_file("secure-data", "main-files/secure-data.pdf", "files/secure-data.pdf.encrypted");

}


void create_encrypted_file(char *file_name, char *read_filepath, char *write_filepath){

    printf("\n================ %s ================\n", file_name);
    unsigned char *contents_buffer = NULL;
    uint32_t contents_size = 0;

    contents_size = read_file(read_filepath, &contents_buffer);
    // print_buffer(contents_buffer, read_filepath, contents_size);

    obfuscator(contents_buffer, contents_size);
    // print_buffer(contents_buffer, write_filepath, contents_size);   

    int write_counter = write_file(write_filepath, contents_buffer, contents_size);
    printf("\nwrite_counter: %d", write_counter);
}



void print_buffer(char *buffer, char* name, uint32_t size){
    printf("\n\n%s: ", name);
    printf("\nsize: %d\n", size);
    
    int i=0;
    while (i < size){
        printf("%x ", buffer[i]);
        i++;
    }
    printf("\n");
}

uint32_t read_file(char *filename, unsigned char **contents_out)
{
    FILE *h_file;
    char *resized_buffer;
    int ch;
    uint32_t buffer_size = 1024;
    uint32_t read_counter = 0;
    if(*contents_out != NULL)
    {
        printf("error: contents_out was not NULL!\n");
        return read_counter;
    }
    // open the file handle in read bytes mode
    h_file = fopen(filename, "rb");
    // check to see if we got a valid handle back
    if (h_file == NULL)
    {
        printf("error: failed to read file\n");
        return read_counter;
    }
    // allocate our initial read buffer
    *contents_out = calloc(buffer_size, sizeof(char));
    do {
        // grab a character from the file
        ch = fgetc(h_file);
        if(EOF != ch)
        {
            // add the character to the buffer at the current counter
            (*contents_out)[read_counter] = (char) ch;
            read_counter += 1;
        }
        // check to see if we are running out of room in the buffer
        if (read_counter >= buffer_size - 1)
        {
            // increase the buffer size by the specified increment
            buffer_size += 1024;
            // reallocate a new buffer
            resized_buffer = realloc(*contents_out, buffer_size);
            // check to see if the realloc worked
            if(resized_buffer == NULL)
            {
                // we have memory issues so debug print and bail
                *contents_out = NULL;
                read_counter = 0;
                return read_counter;
            }
            // set contents buffer to the potentially new pointer
            *contents_out = resized_buffer;
        }
    } while (ch != EOF);
    if (feof(h_file))
    {
        printf("reached end of stream on write\n");
    }
    if (ferror(h_file))
    {
        printf("error: failed to read whole file\n");
    }
    fclose(h_file);
    // should return null if broken, otherwise pointer to file data.
    return read_counter;
}

void obfuscator(unsigned char *contents, uint32_t contents_size){
    int i;
    int j;
    unsigned char key[] = "5h0wd0wn";
    int key_length = strlen(key);

    // printf("\nkey_length: %d\n", key_length);
    // printf("key: ");
    // for (j=0; j< key_length; j++){
    //     printf("%x ", key[j]);
    // }

    printf("\n");
    for (i=0; i < contents_size; i++){
        int mod_i = i % key_length;
        // printf("\n %x, %d, %d, %x,",  contents[i], mod_i, mod_i, key[mod_i]); // Part 1 of printing
        contents[i] = (ror((contents[i] ^ key[mod_i]), mod_i)) - mod_i;
        // printf(" %x", contents[i]); // Part 2 of printing 
    }
}

unsigned char rol(unsigned char num, int n) {
    return (num << n) | (num >> (8 - n));
}

unsigned char ror(unsigned char num, int n) {
    return (num >> n) | (num << (8 - n));
}

uint32_t write_file(char *filename, unsigned char *contents, uint32_t contents_size)
{
    FILE *h_file;
    uint32_t write_counter = 0;
    //printf("%s\n", contents);
    if(contents == NULL)
    {
        printf("error: contents to write was NULL\n");
        return write_counter;
    }
    // open the file handle in write bytes mode
    h_file = fopen(filename, "wb");
    // check to see if we got a valid handle back
    if (h_file == NULL)
    {
        printf("error: failed to write file\n");
        return write_counter;
    }
    for(write_counter = 0; write_counter < contents_size; write_counter++)
    {
        fputc(contents[write_counter], h_file);
        if (ferror(h_file))
        {
            printf("error: while writing file\n");
            break;
        }
    }
    fclose(h_file);
    return write_counter;
}