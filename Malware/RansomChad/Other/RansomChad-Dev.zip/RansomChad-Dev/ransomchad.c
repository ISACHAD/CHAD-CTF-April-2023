#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>

uint32_t read_file(char *filename, unsigned char **contents_out);
uint32_t write_file(char *filename, unsigned char *contents, uint32_t contents_size);
void banner();
void stage(char *filename, unsigned char* input);
unsigned char rol(unsigned char num, int n);
unsigned char ror(unsigned char num, int n);

int main(int argc, char **argv){
    
    banner();

    char *jaypeegee_filename = (char*) calloc(100, sizeof(char));
    sprintf(jaypeegee_filename, "%s","files/JayPeeGee.jpg.encrypted");
    char *alphabet_filename = (char*) calloc(100, sizeof(char));
    sprintf(alphabet_filename, "%s","files/alphabet-lowercase.txt.encrypted");
    char *mybookreport_filename = (char*) calloc(100, sizeof(char));
    sprintf(mybookreport_filename, "%s","files/mybookreport.png.encrypted");
    char *secure_data_filename = (char*) calloc(100, sizeof(char));
    sprintf(secure_data_filename, "%s","files/secure-data.pdf.encrypted");
    char input[9];

    printf("\n\nWhat's the key: ");
    fscanf(stdin, "%s", &input); // TODO use something more secure?

    if (strlen(input) != 8){
        exit(0);
    }

    stage(jaypeegee_filename, input);
    stage(alphabet_filename, input);
    stage(mybookreport_filename, input);
    stage(secure_data_filename, input);

	free(jaypeegee_filename);
    free(alphabet_filename);
    free(mybookreport_filename);
    free(secure_data_filename);

}


void banner ()
{   
    printf("                                            _________________                                              \n");
    printf("                                            |# :           : #|                                            \n");
    printf("                                            |  :           :  |                                            \n");
    printf("                                            |  :           :  |                                            \n");
    printf("                                            |  :           :  |                                            \n");
    printf("                                            |  :___________:  |                                            \n");
    printf("                                            |     _________   |                                            \n");
    printf("                                            |    | __      |  |                                            \n");
    printf("                                            |    ||  |     |  |                                            \n");
    printf("                                            \\____||__|_____|__|                                            \n\n");

    printf("It appears your files have been encrypted ;) Either pay me 1000 CHADcoins or you can try to find the key. Your choice!\n");
    printf("Feed me the key I desire and see the accompanying files become useful. You'll know when you got the right key.\n");
    printf("Please keep the files the in the below structure. Output files will be placed in files/\n");
    printf("If for some reason your *.encrypted files are deleted, just ask CTF staff for copies\n\n");
    printf("RansomChad/\n");
    printf("    files/\n");
    printf("        alphabet-lowercase.txt.encrypted\n");
    printf("        JayPeeGee.jpg.encrypted\n");
    printf("        mybookreport.png.encrypted\n");
    printf("        secure-data.pdf.encrypted\n");
    printf("    ransomchad");


}

void stage(char *filename, unsigned char* input){
    
    unsigned char *contents_buffer = NULL;
    uint32_t contents_size = 0;
    int i;
    int input_length = strlen(input);
    char *new_filename = (char*) calloc(100, sizeof(char));
    char *filename_prefix= NULL;
    char *filename_type = NULL;

    contents_size = read_file(filename, &contents_buffer);

    for (i=0; i<contents_size; i++){
        int mod_i = i % input_length;
        contents_buffer[i] = rol((contents_buffer[i] + mod_i), mod_i) ^ input[mod_i];
    }

    filename_prefix = strtok(filename, ".");
    filename_type = strtok(NULL, ".");
    sprintf(new_filename, "%s.%s", filename_prefix, filename_type);

    write_file(new_filename, contents_buffer, contents_size);

    if (new_filename != NULL){
        free(new_filename);
    }
    

}

unsigned char rol(unsigned char num, int n) {
    return (num << n) | (num >> (8 - n));
}

unsigned char ror(unsigned char num, int n) {
    return (num >> n) | (num << (8 - n));
}

uint32_t read_file(char *filename, unsigned char **contents_out)
{
    FILE *h_file;
    char *resized_buffer;
    int ch;
    uint32_t buffer_size = 1024;
    uint32_t read_counter = 0;

    h_file = fopen(filename, "rb");

    *contents_out = calloc(buffer_size, sizeof(char));
    do {
        ch = fgetc(h_file);
        if(EOF != ch)
        {
            (*contents_out)[read_counter] = (char) ch;
            read_counter += 1;
        }
        if (read_counter >= buffer_size - 1)
        {
            buffer_size += 1024;
            resized_buffer = realloc(*contents_out, buffer_size);

            *contents_out = resized_buffer;
        }
    } while (ch != EOF);

    fclose(h_file);
    return read_counter;
}

uint32_t write_file(char *filename, unsigned char *contents, uint32_t contents_size)
{
    FILE *h_file;
    uint32_t write_counter = 0;

    h_file = fopen(filename, "wb");

    for(write_counter = 0; write_counter < contents_size; write_counter++)
    {
        fputc(contents[write_counter], h_file);
    }
    fclose(h_file);
    return write_counter;
}