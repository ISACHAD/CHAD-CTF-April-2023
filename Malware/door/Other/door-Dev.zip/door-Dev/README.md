# door
 
Created by Felipe Pineda

Category: Medium

## Story
Open the door :)

*Note: When typing in key into debugger, make sure you don't type any newlines, whitepaces, or any extra keys.*

## Structure

- door-Dev/ are files used to craft this challenge. Go nuts with these files if you need to understand the challenge to provide help. Code may be a bit ugly...

## Overview
*Originally an EASY challenge, but had to change it to Medium*
- The challenge teaches players how to RE binaries by loading the program into a debugger.

- The gist here is to use what I've provide to RE the flag. The player will have the obfuscated flag (printed out in the banner), the starting 5 characters "CHAD{", and once you step through the binary, the alrogithm (XOR->NOT)
  - [CyberChef Indivudal Byte](https://gchq.github.io/CyberChef/#recipe=NOT()XOR(%7B'option':'Hex','string':'CC'%7D,'Standard',false)To_Hex('Space',0)&input=Qw)
    - I give the use the "C" in "CHAD{" and the "CC" in the obfuscated flag. The algorithm (within cyberchef) is obtained through REing. The resulting "70" is the hex value for "p" on the key `p!zz@`.
  - [CyberChef Entire](https://gchq.github.io/CyberChef/#recipe=NOT()XOR(%7B'option':'Hex','string':'cc%2096%20c4%20c1%20c4%20db%2096%20b6%20da%20fc%20c7%20ed%20b6%20d6%208c%20d0%208a%20c5%20dd%20c2'%7D,'Standard',false)&input=Q0hBRHs)
    - Given "CHAD{"  and the obfuscated flag (XOR Key in this case) `cc 96 c4 c1 c4 db 96 b6 da fc c7 ed b6 d6 8c d0 8a c5 dd c2`




## Solution/Walthrough
*goes without saying the player will need gdb or their debugger of choice :)*
- Go ahead and open it in a debugger. I recommend gdb with gef.
- The first thing  you will see is the obfuscated flag being assigned. It's obfuscated, so unless you know the algorithm and key already, there is no way it can be deobfuscated beforehand. This is the flag that will be ran through the algorithm with the key entered by the user. It will look different at the end of the program. If it has the correct key, then it will become the correct flag. If it gets the incorrect key, then it will become a incorrect flag. I actually print it out in the banner as the user may find it userful. `\xcc\x96\xc4\xc1\xc4\xdb\x96\xb6\xda\xfc\xc7\xed\xb6\xd6\x8c\xd0\x8a\xc5\xdd\xc2`
- Next, it prints out the banner
- Asks the user to input the key, 
- Checks if the key is larger than 5.
- Stage functions is where the deobfuscation occurs
  - Takes the length of the obfuscated flag for later use
  - takes the length of the input for later use
  - runs through algorithm. See below on notes for the assmebly/C code.
```
...
idiv   $esi                             # i % input_len
movsxd rdx, edx                         # above operation result into edx
movzx  eax, BYTE PTR [rbx+rdx*1]        # eax=byte out of input
movsxd rdx, ecx
add    rdx, r12                         # rdx=pointer to the obfuscated string
xor    al, BYTE PTR [rdx]               # BYTE [rdx]=byte from obfuscated string; al=byte out of input
not    eax                              # applies not to the result from above
mov    BYTE PTR [rdx], al               # resulting value is 0xFFFFFFXX where XX is the value; only takeing XX
add    ecx, 0x1                         # adds one to looping index
cmp    ecx, ebp                         # compares just how a normal loop functions
...
```

```C
void stage(char *obfuscated_flag, char *input) {
    int obfuscated_flag_len = strlen(obfuscated_flag);
    int input_len = strlen(input);

    for ( int i=0 ; i < obfuscated_flag_len ; i++ ) {
		obfuscated_flag[i] ^= ~input[i % input_len];

	}

}
```
  - [CyberChef](https://gchq.github.io/CyberChef/#recipe=From_Hex('Auto')XOR(%7B'option':'Hex','string':'70'%7D,'Standard',false)NOT()To_Hex('Space',0)&input=Y2M)
    - cc is the `\xcc` in the obuscated_flag.
    - 70 is the "p" in the key: `p!zza`
    - Result is the "C" in `CHAD{TH3_CH33S3_T@X}`

- Prints out the flag out that it arrived at after doing the algorithm.

*If you get lost just reference the C code. I am providing the code, so you can recompile with `ggdb` and see the code line up with the assembly. You'll be able to step through it with the source code.

Key `p!zz@`

FLAG: `CHAD{TH3_CH33S3_T@X}`

## Hints
1.  The flag itself begins with CHAD{ Maybe you can use that information O__o
2.  NOT XOR, think what two values you have and what value you are trying to get? Also the key is only 5 chars long? The flag looks long so how can 5 chars be able to do mathing against a larger string????



