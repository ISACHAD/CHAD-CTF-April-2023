#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void create_stage();
void stage();

int main(int argc, char **argv){
    // Comment out stage(); and run create_stage() with the flag in hex of your choice and the key of of your choice
    // it will output the hex obfuscated key, then copy that and plug that into the array obfuscated_flag[] in create stage
    // also copy your key to the stage() function
    // uncomment and run stage(); it should output the obuscated data and the string correct flag. if not something went wrong


    create_stage();
    stage();


}

void create_stage(){

    // hex string for "CHAD{TH3_CH33S3_T@X}"
    unsigned char flag[] = "\x43\x48\x41\x44\x7b\x54\x48\x33\x5f\x43\x48\x33\x33\x53\x33\x5f\x54\x40\x58\x7d"; 

    char key[] = "p!zz@";

    unsigned char obfuscated_flag[strlen(flag)]; // empty char string to put the values


    printf("obfuscated flag: ");
    for (int i=0; i < strlen(flag); i++) {
        obfuscated_flag[i] = flag[i] ^ ~key[i % strlen(key)];

        printf("%x ",  obfuscated_flag[i]); 
    }
    printf("\n");

}

void stage() {
    // key that user will be putting to solve it, putting it here to go ahead save time to output answer
    char key[] = "p!zz@";

    char obfuscated_flag[] = "\xcc\x96\xc4\xc1\xc4\xdb\x96\xb6\xda\xfc\xc7\xed\xb6\xd6\x8c\xd0\x8a\xc5\xdd\xc2";

    for ( int i=0 ; i < strlen(obfuscated_flag) ; i++ ) {
		obfuscated_flag[i] ^= ~key[i % strlen(key)];
        // mode values: 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
	}

    printf("deobfuscated: %s\n", obfuscated_flag);

}


