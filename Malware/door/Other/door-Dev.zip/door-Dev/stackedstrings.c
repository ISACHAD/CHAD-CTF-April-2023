#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int obfuscate(int a);
char* decodeMe(char* data, int len);


int main(int argc, char **argv){
    

    // CHAD{TH3_CH33S3_T@X} [20]
    char* MyString2 = (char*) calloc(21, sizeof(char));

    
    *MyString2 = 68; // C
    *(MyString2 + 1) =  73;  // H
    *(MyString2 + 2) =  70-4; // A
    *(MyString2 + 3) =  obfuscate(69); // D
    *(MyString2 + 4) =  124; // {
    *(MyString2 + 5) =  85; // T
    *(MyString2 + 6) =  obfuscate(73); // H
    *(MyString2 + 7) =  '4'; // 3
    *(MyString2 + 8) =  96; // _
    *(MyString2 + 9) =  68; // C
    *(MyString2 + 10) =  73; // H
    *(MyString2 + 11) =  '4'; // 3
    *(MyString2 + 12) =  '4'; // 3
    *(MyString2 + 13) =  obfuscate(84); // S
    *(MyString2 + 14) =  '4'; // 3
    *(MyString2 + 15) =  100-4; // _
    *(MyString2 + 16) =  85; // T
    *(MyString2 + 17) =  69-4; // @
    *(MyString2 + 18) =  89; // X
    *(MyString2 + 19) =  obfuscate(126); // }



    printf("\n%d", strlen("CHAD{TH3_CH33S3_T@X}"));
    printf("\n%d", strlen(MyString2));

    printf("\nthe result : %s", decodeMe(MyString2,20));

    // printf("\n%c", Obfuscate('105'))
    // printf("\n%c", '0'+1);
    return 0;
}

int obfuscate(int a) {

    return ((a+5)-5);
}

char* decodeMe(char* data, int len) {

    for (int i = 0; i < len; i++) {
        data[i] = data[i] - 1;
    }
    return data;
}