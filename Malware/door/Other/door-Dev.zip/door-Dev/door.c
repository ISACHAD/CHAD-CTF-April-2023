#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void banner();
void stage(char *obfuscated_flag, char *input);

int main(int argc, char **argv){

    char input[6];
    unsigned char obfuscated_flag[] = "\xcc\x96\xc4\xc1\xc4\xdb\x96\xb6\xda\xfc\xc7\xed\xb6\xd6\x8c\xd0\x8a\xc5\xdd\xc2";
    
	banner();
	
    printf("\n\nGimme dat key: ");
    fgets(input, 6, stdin);

	stage(obfuscated_flag, input);

    printf("\n\nIs this your flag?\n");
	printf("%s", obfuscated_flag);

}


void banner ()
{
	printf("\n\n		 _______________			\n");
	printf("		|\\ ___________ /|		\n");	
	printf("		| |  _ _ _ _  | |		\n");
	printf("		| | | | | | | | |		\n");
	printf("		| | |-+-+-+-| | |		\n");
	printf("		| | |-+-+-+-| | |		\n");
	printf("		| | |_|_|_|_| | |		\n");
	printf("		| |     ___   | |		\n");
	printf("		| |    /__/   | |		\n");
	printf("		| |   [\%==] ()| |		\n");
	printf("		| |         ||| |		\n");
	printf("		| |         ()| |		\n");
	printf("		| |           | |		\n");
	printf("		| |           | |		\n");
	printf("		| |           | |		\n");
	printf("		|_|___________|_|		\n\n\n");


    printf("Give it the key it wants and you'll get a flag.\n");
    unsigned char obfuscated_flag[] = "\xcc\x96\xc4\xc1\xc4\xdb\x96\xb6\xda\xfc\xc7\xed\xb6\xd6\x8c\xd0\x8a\xc5\xdd\xc2";
    printf("This may be of use: ");
    for (int i=0; i < strlen(obfuscated_flag); i++) {
            printf("%x ",  obfuscated_flag[i]); 
    }
}

void stage(char *obfuscated_flag, char *input) {
    int obfuscated_flag_len = strlen(obfuscated_flag);
    int input_len = strlen(input);

    for ( int i=0 ; i < obfuscated_flag_len ; i++ ) {
		obfuscated_flag[i] ^= ~input[i % input_len];

	}

}

