#!/bin/sh

node challenge.js&
node admin.js